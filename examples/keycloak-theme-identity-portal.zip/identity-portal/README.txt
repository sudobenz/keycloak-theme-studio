Identity Portal — Keycloak Theme

Theme: identity-portal
Target version: 26.1.4
Types: account, admin, email, login, welcome

Copy the theme directory into the Keycloak themes/ directory.
Review compatibility and validate the theme on a non-production Keycloak instance.
