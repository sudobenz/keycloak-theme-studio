# Projet Keycloakify — Identity Portal

Ce projet utilise React, Vite et Keycloakify 11.16.4.

## Pré-requis

- Node.js 18 ou supérieur (Node 20 recommandé)
- Java 17 ou supérieur
- Maven 3.8 ou supérieur

## Construire le thème

```bash
npm install
npm run build-keycloak-theme
```

Les JAR Keycloakify sont générés dans `dist_keycloak/`. Pour Keycloak 11–21 et 26+, utilisez `keycloak-theme-for-kc-all-other-versions.jar`. Pour Keycloak 22–25, utilisez `keycloak-theme-for-kc-22-to-25.jar`.

## Types de thèmes

La partie Login est construite avec les composants React officiels de Keycloakify. Les types sélectionnés supplémentaires (Account, Admin, Email et Welcome) sont conservés par le générateur Keycloak natif du Studio. Le fichier `native-sidecar.jar` conserve le JAR natif complet, y compris les templates FreeMarker et les ressources personnalisées. Il sert de repli sans perte si le projet React doit être reconstruit ou adapté. Pour produire un JAR combiné directement depuis le Studio, utilisez **Exporter → JAR React / Keycloakify**. Le JAR natif reste disponible séparément et n'est pas modifié par ce moteur.

Les templates FreeMarker Login éventuellement ajoutés dans le Studio ne sont pas injectés dans le rendu React : utilisez le **JAR natif** si vous devez conserver un remplacement de `login.ftl` ou d'un autre template Login.

## Références

- https://docs.keycloakify.dev/
- https://github.com/keycloakify/keycloakify-starter
