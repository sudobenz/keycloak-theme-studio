import { createRoot } from "react-dom/client";
import { StrictMode } from "react";
import { KcPage } from "./kc.gen";
import "./login/main.css";

if (import.meta.env.DEV && !window.kcContext) {
  const { getKcContextMock } = await import("./login/KcPageStory");
  window.kcContext = getKcContextMock({ pageId: "login.ftl", overrides: {} });
}

const root = document.getElementById("root");
if (!root) throw new Error("Missing #root mount element");
createRoot(root).render(
  <StrictMode>
    {window.kcContext ? <KcPage kcContext={window.kcContext} /> : <div />}
  </StrictMode>
);
